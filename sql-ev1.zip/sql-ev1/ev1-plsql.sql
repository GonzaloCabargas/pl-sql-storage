/*
        PROFESOR ES IMPORTANTE QUE LEA ESTO!!!
        
LOS PORCENTAJES ENTREGADOS EN EL WORD (PUNTO B Y E REGLAS DE NEGOCIO)
NO CORRESPONDEN A LOS PORCENTAJES APLICADOS A LOS RESULTADOS DEL PROCESO ESTIPULADOS EN
LA "TABLA INFO_VENTA_VENDEDOR". AHORA BIEN LOS RESULTADOS QUE HE SUBIDO
ESTAN HECHOS BASANDOME EN LOS PORCENTAJES OTORGADOS EN LAS REGLAS DE NEGOCIOS
Y POR ENDE LOS VALORES DE LA TABLA "COMISION_VENTA_VENDEDOR" TAMBIEN SE VIERON ALTERADOS.
*/

set SERVEROUTPUT ON
var b_fecha varchar2(30);
exec :b_fecha := '202105';

var b_porc1 number;
exec :b_porc1 := 0.15;
var b_porc2 number;
exec :b_porc2 := 0.12;
var b_porc3 number;
exec :b_porc3 := 0.10;
var b_porc4 number;
exec :b_porc4 := 0.08;
var b_porc5 number;
exec :b_porc5 := 0.05;

DECLARE
  v_min_id number;
  v_max_id number;
  v_nro_ventas number;
  v_total_neto_ventas number;  
  v_nombre_ven varchar2(50);
  v_nom_grupo grupo.nom_grupo%type;
  v_asignacion_ventas number;
  v_id_categoria char(1);
  v_porc_categoria number;
  v_ince_categoria number;
  v_id_grupo grupo.id_grupo%type;
  v_porc_grupo number;
  v_bono_grupo number;
  v_antiguedad number;
  v_asig_antiguedad number;
  v_descuento number;
  v_total_mensual number;
  v_porc_comision number;
  v_comision_vend number;
BEGIN

/*SE TRUNCAN LAS TABLAS PARA ELIMINAR CUALQUIER REGISTRO*/

EXECUTE IMMEDIATE ('TRUNCATE TABLE INFOVENTA_VENDEDOR');
EXECUTE IMMEDIATE ('TRUNCATE TABLE COMISION_VENTA_VENDEDOR');

--SACAR EL MINIMO ID DE VENDEDOR Y EL MAXIMO PARA PODER RECORRER CADA FILA
    select min(id_vendedor), max(id_vendedor) 
    into v_min_id, v_max_id
    from vendedor;
    
    DBMS_OUTPUT.PUT_LINE(' ');
    DBMS_OUTPUT.PUT_LINE('***************************************');
    DBMS_OUTPUT.PUT_LINE(' ');
    
--SE CREA EL CICLO PARA RECORRER LAS FILAS SEGUN EL ID DEL VENDEDOR
    while v_min_id <= v_max_id loop

/*A) DATOS DE VENTAS (CANTIDAD DE VENTAS y TOTAL NETO) SEGUN LA FECHA INGRESADA POR VAR BIND
*/  
    select 
    count(*),sum(dev.cantidad * ar.precio)  
    into v_nro_ventas, v_total_neto_ventas
    from venta v
    join detalleventa dev on v.id_venta = dev.id_venta 
    join articulo ar on dev.id_articulo = ar.id_articulo
    where to_char(v.fecha_venta,'yyyymm') = :b_fecha and v.id_vendedor = v_min_id
    group by v.id_vendedor;

/*  DATOS DEL VENDEDOR (NOMBRE, NOMBRE DE GRUPO,ID DEL GRUPO,
    ID CATEGORIZACION, ANTIGUEDAD(EN A�OS))
*/
    select 
    v.nombres||' '||v.apellidos, gr.nom_grupo, v.id_categoria,
    v.id_grupo, round(months_between(sysdate,v.feccontrato)/12)
    into v_nombre_ven, v_nom_grupo, v_id_categoria, v_id_grupo, v_antiguedad
    from vendedor v
    join grupo gr on v.id_grupo = gr.id_grupo
    where id_vendedor = v_min_id;

/*B) ASIGNACION POR VENTAS  
     UTILIZANDO LOS PORCENTAJES ENTREGADOS EN LAS REGLAS DE NEGOCIO
*/
    v_asignacion_ventas := round(CASE 
        WHEN v_nro_ventas >= 10 THEN v_total_neto_ventas * :b_porc1
        WHEN v_nro_ventas between 8 and 9 THEN v_total_neto_ventas * :b_porc2
        WHEN v_nro_ventas between 6 and 7 THEN v_total_neto_ventas * :b_porc3
        WHEN v_nro_ventas between 3 and 5 THEN v_total_neto_ventas * :b_porc4
        WHEN v_nro_ventas between 1 and 2 THEN v_total_neto_ventas * :b_porc5
       ELSE 0 END);

/*C) INCENTIVO POR CATEGORIZACION*/
    select porcentaje/100
    into v_porc_categoria
    from categoria
    where id_categoria = v_id_categoria;
    v_ince_categoria := round(v_total_neto_ventas * v_porc_categoria);

/*D) BONO POR GRUPO*/
    select porc/100 
    into v_porc_grupo
    from grupo
    where id_grupo = v_id_grupo;
    v_bono_grupo := round(v_total_neto_ventas * v_porc_grupo);

/*E) ASIGNACION POR ANTIGUEDAD
     SE UTILIZARON LOS PORCENTAJES ENTREGADOS EN LAS REGLAS DE NEGOCIOS */
    if v_antiguedad >10 then
        v_asig_antiguedad := v_total_neto_ventas * 0.22;
    elsif v_antiguedad between 6 and 10 then
        v_asig_antiguedad := v_total_neto_ventas * 0.16;
    elsif v_antiguedad between 3 and 5 then
        v_asig_antiguedad := v_total_neto_ventas * 0.07;
    else v_asig_antiguedad := 0;
    end if;
    
/*F) DESCUENTOS CORRESPONDIENTES AL MES ANTERIOR AL PROCESO*/
    select monto
    into v_descuento 
    from anticipo
    where mes = substr(:b_fecha,-2)-1 and id_vendedor = v_min_id;
    
/*G) TOTAL MENSUAL DEL VENDEDOR */
    v_total_mensual := v_total_neto_ventas+v_asignacion_ventas+
    v_ince_categoria+v_bono_grupo+round(v_asig_antiguedad)-v_descuento;
    
/*H) COMISIONES MENSUALES PARA LOS VENDEDORES*/
    select comision/100
    into v_porc_comision
    from comisionvendedor
    where v_total_mensual between ventaminima and ventamaxima;
    v_comision_vend := round(v_total_mensual * v_porc_comision);

    
    --SALIDAS DE CONSOLA    
    DBMS_OUTPUT.PUT_LINE('ID_VENDEDOR= '||v_min_id);
    DBMS_OUTPUT.PUT_LINE('NOMBRE= '||v_nombre_ven);
    DBMS_OUTPUT.PUT_LINE('GRUPO_EMP= '||v_nom_grupo);
    DBMS_OUTPUT.PUT_LINE('NRO_VENTAS= '||v_nro_ventas);
    DBMS_OUTPUT.PUT_LINE('VENTAS_NETAS_MES= '||v_total_neto_ventas);
    DBMS_OUTPUT.PUT_LINE('BONO_GRUPO= '||v_bono_grupo);
    DBMS_OUTPUT.PUT_LINE('INCENTIVO_CATEGORIA= '||v_ince_categoria);
    DBMS_OUTPUT.PUT_LINE('ASIGNACION_VTAS= '||v_asignacion_ventas);
    DBMS_OUTPUT.PUT_LINE('ASIGNACION_ANTIG= '||round(v_asig_antiguedad));
    DBMS_OUTPUT.PUT_LINE('ANTICIPOS= '||v_descuento);
    DBMS_OUTPUT.PUT_LINE('TOTALES_MES= '||v_total_mensual);
    DBMS_OUTPUT.PUT_LINE('v_comision_vend= '||v_comision_vend);
    DBMS_OUTPUT.PUT_LINE(' ');
    DBMS_OUTPUT.PUT_LINE('***************************************');
    DBMS_OUTPUT.PUT_LINE(' ');
    
/*INSERCION DE DATOS A TABLAS INFOVENTA_VENDEDOR Y COMISION VENTA VENDEDOR*/

    insert into infoventa_vendedor values(
    to_char(sysdate,'yyyy')-1,substr(:b_fecha,-2),v_min_id,v_nombre_ven,v_nom_grupo,
    v_nro_ventas,v_total_neto_ventas,v_bono_grupo,v_ince_categoria,v_asignacion_ventas,
    v_asig_antiguedad,v_descuento,v_total_mensual
    );
    
    insert into comision_venta_vendedor values(
    to_char(sysdate,'yyyy')-1,substr(:b_fecha,-2),v_min_id,
    v_total_mensual,v_comision_vend
    );
    
 
--SE AUTOINCREMENTA EL ID DEL VENDEDOR EN 5    
    v_min_id := v_min_id + 5;
    end loop;  
END;
--MOSTRANDO LOS RESULTADOS DE LA INSERSION DE DATOS REALIZADA ANTEERIORMENTE
select * from infoventa_vendedor;
select * from comision_venta_vendedor;