set serveroutput on

--CASO NRO1

--SOLUCION N�1----------------------------------------------------
DECLARE
   -- cursor que recupera las profesiones
   CURSOR c1 IS
   SELECT *
   FROM profesion
   where cod_profesion in (select cod_profesion
                          from profesional);
   --SE CREA UN RECORD EL CUAL AYUDARA A RECORER EL CURSOR c1
   record_1 C1%ROWTYPE;
   -- cursor que recupera productos de cada vi�atero
   -- recibe como par�metro la id del productor
   CURSOR c2 (n NUMBER) IS
   SELECT *
   FROM profesional
   WHERE cod_profesion = n;
   --SE CREA UN RECORD PARA RECORRER EL CURSOR c2
   record_2 c2%ROWTYPE;
   counter number := 0;

BEGIN
    --SE PREGUNTA SI EL CURSOR ESTA ABIERTO, EN CASO DE SER CIERTO, INICIA EL LOOP
    if not c1%ISOPEN then
        open c1;
    end if;
    loop
        --SE HACE EL FETCH PARA RECUPERAR LOS REGISTROS DEL CURSOR
        fetch c1 INTO record_1;
        --SALE CUANDO NO ENCUENTRA MAS REGISTROS
        exit when c1%NOTFOUND;
          dbms_output.put_line('####### LISTA DE CONSULTORES DE PROFESION ' || '"' || UPPER(record_1.nombre_profesion || '"'));
          dbms_output.put_line(CHR(13));   
          dbms_output.put_line(lpad('-',65,'-'));
          dbms_output.put_line('  RUN  NOMBRE CONSULTOR      PUNTAJE  SUELDO ACTUAL   NUEVO SUELDO');
          dbms_output.put_line(lpad('-',65,'-'));
          counter := 0;
          --SE PREGUNTA SI EL c2 ESTA ABIERTO, DE NO SER ASI, SE ABRE
          if not c2%ISOPEN then
            open c2(record_1.cod_profesion);
          end if;
          --SE INICIA EL LOOP PARA EL CURSOR c2
          LOOP
            --SE HACE EL FETCH PARA RECUPERAR LOS REGISTROS DEL CURSOR
            fetch c2 INTO record_2;
            --SALE CUANDO NO ENCUENTRA MAS REGISTROS
            EXIT WHEN c2%NOTFOUND;
                 counter := counter + 1;       
                    dbms_output.put_line(rpad(record_2.numrun_prof,10,' ')
                    || ' ' || RPAD(record_2.appaterno || ' ' || record_2.nombre, 20,' ')
                    || ' ' || TO_CHAR(record_2.puntaje,'999')
                    || ' ' || rpad(TO_CHAR(record_2.sueldo, '$9G999G999'),15, ' ')
                    || ' ' || TO_CHAR(record_2.sueldo * 1.1, '$9G999G999'));
          END LOOP;
          --SE CIERRA EL CURSOR c2 UNA VEZ HAYA SIDO RECORRIDO
          close c2;    
          dbms_output.put_line(lpad('-',65,'-'));      
          dbms_output.put_line('Total de consultores : ' || counter);      
          dbms_output.put_line(CHR(12));
    END LOOP;
    --SE CIERRA EL CURSOR c2 UNA VEZ HAYA SIDO RECORRIDO
    close c1;
END;

--SOLUCION N�2------------------------------------------------------------------
--USANDO CICLO WHILE
DECLARE
   -- cursor que recupera las profesiones
   CURSOR c1 IS
   SELECT *
   FROM profesion
   where cod_profesion in (select cod_profesion
                          from profesional);
   --SE CREA UN RECORD EL CUAL AYUDARA A RECORER EL CURSOR c1
   record_1 C1%ROWTYPE;
   -- cursor que recupera productos de cada vi�atero
   -- recibe como par�metro la id del productor
   CURSOR c2 (n NUMBER) IS
   SELECT *
   FROM profesional
   WHERE cod_profesion = n;
   --SE CREA UN RECORD PARA RECORRER EL CURSOR c2
   record_2 c2%ROWTYPE;
   counter number := 0;

BEGIN
    --SE ABRE EL CURSOR Y SE HACE EL FETCH 
    open c1;
    fetch c1 into record_1;
    --SE INDICA QUE MIENTRAS ENCUENTRE REGISTROS EN c1 HAGA UN CICLO WHILE
    while c1%found
    loop
        --EN CASO DE NO ENCONTRAR REGISTROS, TERMINARA EL CICLO WHILE
        if c1%notfound then
            exit;
        end if;
          dbms_output.put_line('####### LISTA DE CONSULTORES DE PROFESION ' || '"' || UPPER(record_1.nombre_profesion || '"'));
          dbms_output.put_line(CHR(13));   
          dbms_output.put_line(lpad('-',65,'-'));
          dbms_output.put_line('  RUN  NOMBRE CONSULTOR      PUNTAJE  SUELDO ACTUAL   NUEVO SUELDO');
          dbms_output.put_line(lpad('-',65,'-'));
          --SE HACE EL FETCH NUEVAMENTE PARA EVITAR LOOP INFINITO
          fetch c1 into record_1;
          counter := 0;
          --SE ABRE EL CURSOR Y SE HACE EL FETCH 
          open c2(record_1.cod_profesion);
          fetch c2 into record_2;
          --SE INICIA EL CICLO WHILE PARA EL CURSOR c2
          while c2%found
          LOOP
            --SALE CUANDO NO ENCUENTRA MAS REGISTROS
            if c2%notfound then
                exit;
            end if;
            --SE HACE EL FETCH NUEVAMENTE PARA EVITAR LOOP INFINITO
            fetch c2 into record_2;
                 counter := counter + 1;       
                    dbms_output.put_line(rpad(record_2.numrun_prof,10,' ')
                    || ' ' || RPAD(record_2.appaterno || ' ' || record_2.nombre, 20,' ')
                    || ' ' || TO_CHAR(record_2.puntaje,'999')
                    || ' ' || rpad(TO_CHAR(record_2.sueldo, '$9G999G999'),15, ' ')
                    || ' ' || TO_CHAR(record_2.sueldo * 1.1, '$9G999G999'));
          END LOOP;
          --SE CIERRA EL CURSOR c2 UNA VEZ HAYA SIDO RECORRIDO
          close c2;    
          dbms_output.put_line(lpad('-',65,'-'));      
          dbms_output.put_line('Total de consultores : ' || counter);      
          dbms_output.put_line(CHR(12));
    END LOOP;
    --SE CIERRA EL CURSOR c2 UNA VEZ HAYA SIDO RECORRIDO
    close c1;
END;

--------------------------------------------------------------------------------
--CASO NRO2


var b_fecha varchar2(20);
exec :b_fecha := '062021';

declare
    v_asig_ev number:=0;
    v_porc_ev number:=0;
    v_asig_profesion number:=0;
    v_total_asig number:=0;
    v_asig_com number:=0;
    
    v_total_asesorias number;
    v_total_honorarios number;
    v_total_asigmov number;
    v_total_asigeva number;
    v_total_asigpro number;
    v_total_asignaciones number;
    
    v_msg_error varchar2(255);
    v_cod_error number;

    
    TYPE tp_traslados IS VARRAY(6) of number;
    v_traslados tp_traslados:=(.02,.04,.05,.07,.09,25000);
    
    CURSOR p1 IS
        SELECT COD_PROFESION COD_PROFESION,
        NOMBRE_PROFESION  NOMBRE_PROFESION,
        ASIGNACION ASIGNACION
        FROM profesion
        where cod_profesion in (select cod_profesion from profesional);
    
    
    CURSOR c1 (n NUMBER) IS
        SELECT 
        TO_CHAR(inicio_asesoria,'MM') mes,
        TO_CHAR(inicio_asesoria,'YYYY') anio,
        p.cod_profesion cod_profesion,
        A.NUMRUN_PROF rut,
        p.nombre||' '||p.appaterno||' '||p.apmaterno nombre,
        pro.NOMBRE_PROFESION profesion,
        CO.COD_COMUNA cod_comuna,
        CO.CODEMP_COMUNA cod_empresarial,
        p.puntaje puntaje,
        p.sueldo sueldo,
        COUNT(*) cant,
        SUM(HONORARIO) total
        FROM ASESORIA A
        JOIN PROFESIONAL P ON a.numrun_prof=p.numrun_prof
        JOIN PROFESION PRO ON pro.cod_profesion=p.cod_profesion
        JOIN COMUNA CO ON co.cod_comuna=p.cod_comuna
        WHERE TO_CHAR(inicio_asesoria,'MMYYYY')=:b_fecha and p.cod_profesion=n
        GROUP BY A.NUMRUN_PROF, inicio_asesoria, p.nombre||' '||p.appaterno||' '||p.apmaterno, pro.NOMBRE_PROFESION, co.COD_COMUNA, CO.CODEMP_COMUNA, p.cod_profesion, puntaje, p.sueldo;

begin
    EXECUTE IMMEDIATE ('TRUNCATE TABLE DETALLE_ASIGNACION_MES');
    EXECUTE IMMEDIATE ('TRUNCATE TABLE RESUMEN_MES_PROFESION');
    EXECUTE IMMEDIATE ('TRUNCATE TABLE ERRORES_P');

    for item in p1 loop
            
        v_total_asesorias:= 0;
        v_total_honorarios:= 0;
        v_total_asigmov:= 0;
        v_total_asigeva:= 0;
        v_total_asigpro:= 0;
        v_total_asignaciones:= 0;
        
        for r1 in c1 (item.cod_profesion) loop
            
           v_total_asesorias:=v_total_asesorias+r1.cant;
           v_total_honorarios:=v_total_honorarios+r1.total;
            
           if (r1.cod_comuna <> 81) then 
            v_asig_com :=trunc(
            CASE WHEN r1.cod_empresarial=10 then r1.total-r1.total*(1 - v_traslados(1))
                 WHEN r1.cod_empresarial=20 then r1.total-r1.total*(1 - v_traslados(2))
                 WHEN r1.cod_empresarial=30 then r1.total-r1.total*(1 - v_traslados(3))
                 WHEN r1.cod_empresarial=40 then r1.total-r1.total*(1 - v_traslados(4))
                 WHEN r1.cod_empresarial is null then v_traslados(6)  
            ELSE r1.total-r1.total*(1 - v_traslados(5)) END);
            else 
                v_asig_com :=0;
            end if;
                v_total_asigmov:=v_total_asigmov+v_asig_com;
            begin    
                select trunc(r1.total-r1.total*(1-(porcentaje/100))),porcentaje
                into v_asig_ev, v_porc_ev
                from  EVALUACION where r1.puntaje between EVA_PUNT_MIN and EVA_PUNT_MAX;
                exception 
                when NO_DATA_FOUND then
                    v_asig_ev:=0;
                    v_msg_error:=SQLERRM;
                    v_cod_error:=SQLCODE;
                    INSERT INTO ERRORES_P VALUES(SQ_ERROR.NEXTVAL,v_mensaje_error, 'no se encuentra el % para el rut: '||r1.rut);
                COMMIT;
                WHEN OTHERS THEN
                    v_asig_ev:=0;
                    v_msg_error:=SQLERRM; 
                    v_cod_error:=SQLCODE; 
                    INSERT INTO ERRORES_P VALUES(SQ_ERROR.NEXTVAL,v_mensaje_error, 'no se encuentra el % para el rut: '||r1.rut);
                COMMIT;
                v_total_asigeva:=v_total_asigeva+v_asig_ev;
            end;
            
            SELECT trunc(r1.sueldo-r1.sueldo*(1-(ASIGNACION/100)))
            INTO v_asig_profesion
            FROM PROFESION
            WHERE  cod_profesion=r1.cod_profesion ;
            
                v_total_asigpro:=v_total_asigpro+v_asig_profesion;
            
                v_total_asig:=v_asig_ev + v_asig_ev + v_asig_profesion;
            
                v_total_asignaciones:=v_total_asignaciones+v_total_asig;
       end loop;
       
            dbms_output.put_line( 'ANNOMES_PROCESO ' || :b_fecha || ' //PROFESION ' || item.NOMBRE_PROFESION || ' //TOTAL_ASESORIAS ' || v_total_asesorias || ' //TOTAL_HONORARIOS ' || v_total_honorarios || ' //TOTAL_ASIGMOV ' || v_total_asigmov || ' //TOTAL_ASIGEVAL ' || v_total_asigeva || ' //TOTAL_ASIGPROFESION' ||v_total_asigpro || ' //Total asig ' || v_total_asignaciones);
            BEGIN
                INSERT INTO RESUMEN_MES_PROFESION VALUES( :b_fecha, item.NOMBRE_PROFESION, v_total_asesorias, v_total_honorarios, v_total_asigmov, v_total_asigeva, v_total_asigpro, v_total_asignaciones);
            EXCEPTION
                WHEN OTHERS THEN
                    v_msg_error:=SQLERRM; 
                    v_cod_error:=SQLCODE; 
                INSERT INTO ERRORES_P VALUES(SQ_ERROR.NEXTVAL,v_msg_error, 'Se encontro un valor mayor que el que permite ');
                COMMIT;
             END;   
    end loop;      
END;

select * from RESUMEN_MES_PROFESION
select * from ERRORES_P