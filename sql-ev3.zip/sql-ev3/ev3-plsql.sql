--CASO1
CREATE OR REPLACE TRIGGER tr_stock
AFTER INSERT OR DELETE OR UPDATE OF CANTIDAD ON DETALLE_BOLETA
FOR EACH ROW
DECLARE
BEGIN
   IF INSERTING THEN
      UPDATE PRODUCTO
          SET totalstock = totalstock - :NEW.CANTIDAD
      WHERE codproducto = :NEW.codproducto;
   ELSIF DELETING THEN
      UPDATE PRODUCTO
      SET totalstock = totalstock + :OLD.CANTIDAD
      WHERE codproducto = :OLD.codproducto;
   ELSE
      UPDATE PRODUCTO
      SET totalstock = totalstock - (:NEW.CANTIDAD - :OLD.CANTIDAD)
      WHERE codproducto = :NEW.codproducto;   
   END IF;
END;
/**/
--CASO2
create or replace  FUNCTION fn_antiguedad (
  p_antiguedad NUMBER,
  p_monto_ventas NUMBER
) RETURN NUMBER
AS
   
    v_asig_eval NUMBER;
    v_mensaje_error varchar2(100);
    v_antiguedad NUMBER;
    v_bono NUMBER;
    v_sql varchar2(300);

BEGIN

        v_sql := ' select (porc_antiguedad/100) * :b_monto_ventas
                    from  porc_antiguedad_empleado
                    where :b_antiguedad between ANNOS_ANTIGUEDAD_INF and ANNOS_ANTIGUEDAD_SUP';

        EXECUTE IMMEDIATE v_sql INTO v_antiguedad USING p_monto_ventas,p_antiguedad ;
        RETURN v_antiguedad;
        EXCEPTION 
        WHEN NO_DATA_FOUND THEN
            v_antiguedad:=0;
            v_mensaje_error:=SQLERRM;
        INSERT INTO ERROR_CALC
        VALUES(SEQ_ERROR.NEXTVAL,v_mensaje_error, 'ERROR EN LA FUNCION, No se econtro el porcentaje para la antiguedad '||p_antiguedad);
        RETURN 0;


        WHEN OTHERS THEN
            v_antiguedad:=0;
            v_mensaje_error:=SQLERRM; 
            INSERT INTO ERROR_CALC
        VALUES(SEQ_ERROR.NEXTVAL,v_mensaje_error, 'ERROR EN LA FUNCION, Se encontro mas de un porcentaje para la antiguedad '||p_antiguedad);
        RETURN 0;



END fn_antiguedad;

/**/

CREATE OR REPLACE PACKAGE pkg_remuneraciones AS
  -- variable publica
  ventas NUMBER(8);
  -- declaracion de la funcion requerida
  FUNCTION fn_ventas (run VARCHAR2,periodo VARCHAR2) RETURN NUMBER;
END pkg_remuneraciones;
--
create or replace  PACKAGE BODY pkg_remuneraciones AS 
  FUNCTION fn_ventas (p_run VARCHAR2,p_periodo VARCHAR2) RETURN NUMBER 
  AS
  
  
    v_ventas NUMBER;

  BEGIN
        select sum(db.totallinea) total_ventas
         into v_ventas
        from boleta b
        join detalle_boleta db on b.numboleta=db.numboleta
        where b.rutcliente=p_run and to_char(b.fecha,'yyyymm')=p_periodo;
        --where b.rutcliente='12456778-1' and to_char(b.fecha,'yyyymm')='202110'
        --group by run_empleado;
        RETURN NVL(v_ventas,0);
        
        EXCEPTION
                WHEN NO_DATA_FOUND THEN
                RETURN 0;
        
  END fn_ventas;  
END pkg_remuneraciones;

/**/

create or replace  PROCEDURE sp_remuneracion 
(p_periodo VARCHAR2)

AS
   
   
   
CURSOR c_empleado IS
   SELECT e.run_empleado run
           ,nombre||' '||paterno||' '||materno nombre
           ,trunc(MONTHS_BETWEEN(SYSDATE,fecha_contrato)/12) antiguedad
           ,e.codcomuna codcomuna
           ,e.sueldo_base sueldo_base
           ,e.codafp codafp
   FROM empleado e;


   v_colacion number;
   v_movilizacion number;
   v_movilizacion_adicional number;
   v_movilizacion_total number;
   v_antiguedad number;
   v_asignacion_ventas number;
   v_sueldo_imponible number;
   v_dcto_afp number;
   v_dcto_salud number;
   v_total_dcto number;
   v_sueldo_liquido number;


   begin

        EXECUTE IMMEDIATE ('TRUNCATE TABLE ERROR_CALC');
        EXECUTE IMMEDIATE ('TRUNCATE TABLE DETALLE_PAGO_MENSUAL');

        for r in c_empleado loop 


        v_colacion := 75000;
        v_movilizacion := 60000;
        dbms_output.put_line( 'rut emp ' || r.run);
        dbms_output.put_line( 'sueldo bruto ' || r.sueldo_base); 
        dbms_output.put_line( 'bono colacion ' || v_colacion); 
        dbms_output.put_line( 'bono movilizacion sa ' || v_movilizacion); 
        v_movilizacion_adicional:= case when r.codcomuna= 1 or r.codcomuna = 7 then r.sueldo_base*(1 - 0.9)
                                     when r.codcomuna= 2 or r.codcomuna = 4 or r.codcomuna = 8 then r.sueldo_base*(1 - 0.88)
                                     when r.codcomuna= 3 or r.codcomuna = 5 or r.codcomuna = 6 then r.sueldo_base*(1 - 0.86)
                                     else r.sueldo_base*(1 - 0.85) end;

        v_movilizacion_total := v_movilizacion+v_movilizacion_adicional;

        dbms_output.put_line( 'bono movilizacion ca ' || v_movilizacion); 

        pkg_remuneraciones.ventas := pkg_remuneraciones.fn_ventas(r.run,p_periodo);


        dbms_output.put_line( 'antiguedad ' || r.antiguedad||'/ ventas '||pkg_remuneraciones.ventas); 

        v_antiguedad := trunc(fn_antiguedad(r.antiguedad,pkg_remuneraciones.ventas));
        dbms_output.put_line( 'bono antiguedad ' || v_antiguedad); 

        begin
            select porc_comision 
                into v_asignacion_ventas
            from porcentaje_comision_venta
            where pkg_remuneraciones.ventas  between venta_inf and venta_sup;
            EXCEPTION 
            WHEN NO_DATA_FOUND THEN
                dbms_output.put_line('No se econtro el porcentaje');
                v_asignacion_ventas:=0;
        end;

        if v_asignacion_ventas <> 0 then 
            v_asignacion_ventas := trunc((v_asignacion_ventas/100)*pkg_remuneraciones.ventas);
        else v_asignacion_ventas := v_asignacion_ventas ;
        end if;

        dbms_output.put_line( 'bono ventas ' || v_asignacion_ventas); 

        v_sueldo_imponible := r.sueldo_base+v_colacion+v_movilizacion+v_antiguedad+v_asignacion_ventas;

        dbms_output.put_line( 'sueldo imponible ' || v_sueldo_imponible); 


        select (porcafp/100)
            into v_dcto_afp
        from prevision_afp
        where codafp=r.codafp;

        v_dcto_afp := trunc(v_dcto_afp*v_sueldo_imponible);
        v_dcto_salud := trunc(0.07*v_sueldo_imponible);
        v_total_dcto := v_dcto_afp+v_dcto_salud;
        dbms_output.put_line( 'descuento afp ' || v_dcto_afp); 
        dbms_output.put_line( 'descuento salud ' || v_dcto_salud); 
        v_sueldo_liquido := v_sueldo_imponible -v_dcto_afp-v_dcto_salud;
        dbms_output.put_line( 'sueldo liquido ' || v_sueldo_imponible); 
        dbms_output.put_line( '---------------');
        
        INSERT INTO DETALLE_PAGO_MENSUAL VALUES(TO_NUMBER(SUBSTR(p_periodo,-2)),TO_NUMBER(SUBSTR(p_periodo,1,4)),r.run,r.nombre,r.sueldo_base,v_colacion,v_movilizacion,v_movilizacion_adicional,v_asignacion_ventas,v_sueldo_imponible,v_total_dcto,v_sueldo_liquido);
        end loop;

   end;
   

   
